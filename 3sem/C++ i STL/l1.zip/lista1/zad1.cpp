#include<iostream>

using namespace std;

int main()
{
	cout<<"??- ??= ??( ??>"; //aby kompilator odczytal trojznaki
	//należy kompilować program z opcja -triagraphs
	return 0;
}