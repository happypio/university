#include<iostream>


int main()
{
	std::cout<<R"(Instytut Informatyki Uniwersytetu Wrocławskiego
ul. Joliot-Curie 15
50-383 Wrocław)";
	std::cout<<'\n'<<R"(C:\katalog użytkowy)"<<'\n';
	std::cout<<R"delimiter("()()""()("(")")"("("()()")"""))")delimiter";
	return 0;
}