import validator.*;

public class Zad1 {
    public static void main(String[] args) {
        if (args[0].equals("1"))
            new TestExpressions();
        else
            new TestInstructions();
    }
}
