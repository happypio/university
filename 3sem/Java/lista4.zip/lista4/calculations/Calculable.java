package calculations;

public interface Calculable {
    public int calculate();
}
