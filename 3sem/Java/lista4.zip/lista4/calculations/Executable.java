package calculations;

public interface Executable {
    public void execute();
}
