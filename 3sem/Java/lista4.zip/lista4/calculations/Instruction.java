package calculations;

public abstract class Instruction implements Executable{
}
