import validator.*;
public class lista5 {
    public static void main (String[] args) {
        new TestOrderedSequence();
    }
}
