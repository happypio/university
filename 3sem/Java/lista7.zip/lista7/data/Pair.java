package data;

public class Pair {
    public int x;
    public int y;
    public Pair(int a, int b){
        x = a;
        y = b;
    }
}
