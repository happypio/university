import test.*;

public class Zad1 {
    public static void main(String[] args){
        Validator.testSOA();
        Validator.testSODA();
    }
    
}
