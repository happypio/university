import graphics.GameWindow;

public class Main {
    public static void main(String args[]) {
        new GameWindow(10, 10, false);
    }
}
