package data;
public class Pair {
    public int x,y;
    public Pair(int a, int b) {
        x = a; y = b;
    }
}
