console.log("Evaluating zad3.js");
exports.variable = 0;
let m_zad3 = require("./modul_zad3.js");
console.log(`In zad3, m_zad3.variable = ${m_zad3.variable}`);
exports.variable = 1;
console.log("end of zad3");