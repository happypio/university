const food = {  
    types: 'only pizza'  
}
console.log(food.types);