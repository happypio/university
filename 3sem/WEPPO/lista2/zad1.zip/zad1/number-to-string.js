var n = 128;
console.log(n.toString());