
public class puzzle_game
{

	public static void main(String[] args)
	{
		new Menu("Menu");
	}
}